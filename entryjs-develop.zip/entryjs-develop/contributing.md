#### 업체PR 가이드

하드웨어 업체에서는

entryjs 레포지토리에서 Pull Request를 보내실때 

devleop-hw브랜치로 보내주시기 바랍니다.

기타 다른브랜치에 PR보내시면 Reject사유가 될수 있습니다.

