// INFO : 웹연결 api의 라이프사이클 함수를 모아놓은 추상 클래스
export default class WebApiConnector {
    connect() {}
    disconnect() {}
    initialDevice() {}
}
