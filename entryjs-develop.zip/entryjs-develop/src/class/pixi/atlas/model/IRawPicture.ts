export interface IRawPicture {
    id:string;
    dimension: { width:number, height:number };
    fileurl:string;
    filename:string;
    name:string;
}