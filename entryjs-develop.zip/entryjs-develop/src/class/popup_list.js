'use strict';

Entry.PopupList = class PopupList {
    constructor(dom) {
        this.view = dom;
    }
    getView() {
        return this.view;
    }

    resize() {}
};
